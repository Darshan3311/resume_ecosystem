package com.zidio_task.resume.resume_ecosystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeEcosystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeEcosystemApplication.class, args);
	}

}
