package com.zidio_task.resume.resume_ecosystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeEcosystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
